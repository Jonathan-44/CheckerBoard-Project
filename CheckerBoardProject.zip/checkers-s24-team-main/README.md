# 2150_Checkers

Developers:
[team]
[Eli Boccolucci] - [eliboccolucci]
[Jonathan Flander] - [Jonathan-44]
[Luke Miller] - [lwmille]
[Steven Spivack] - [SSpivack13] 

This project should be runnable with JDK17 and Junit 4.

You should create your own README. This is the place to give a low-level rundown of what your program does and how someone who isn't a developer could go about using it. If you have any known bugs in the program, this is also a good place to mention those things before your TAs and I find them while grading.
